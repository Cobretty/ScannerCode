using System.Threading.Tasks;
using Microsoft.Maui.ApplicationModel;
using ZXing.Net.Maui;

namespace EscanerEmpresa.Services
{
    public interface IScannerService
    {
        BarcodeReaderOptions BarcodeReaderOptions { get; }
        Task<PermissionStatus> CheckAndRequestCameraPermissionAsync();
        bool ValidateBarcodeFormat(BarcodeResult barcodeResult);
    }

    public class ScannerService : IScannerService
    {
        private readonly BarcodeReaderOptions _readerOptions;
        public BarcodeReaderOptions BarcodeReaderOptions => _readerOptions;

        public ScannerService()
        {
            // Formatos requeridos por Sección 4:
            // EAN-13, EAN-8, UPC-A, UPC-E, CODE_128, CODE_39, ITF
            _readerOptions = new BarcodeReaderOptions
            {
                Formats = BarcodeFormat.Ean13 |
                          BarcodeFormat.Ean8 |
                          BarcodeFormat.UpcA |
                          BarcodeFormat.UpcE |
                          BarcodeFormat.Code128 |
                          BarcodeFormat.Code39 |
                          BarcodeFormat.Itf,
                AutoRotate = true,
                Multiple = false,
                TryHarder = true,
                TryInverted = true
            };
        }

        public async Task<PermissionStatus> CheckAndRequestCameraPermissionAsync()
        {
            PermissionStatus status = await Permissions.CheckStatusAsync<Permissions.Camera>();
            if (status != PermissionStatus.Granted)
            {
                status = await Permissions.RequestAsync<Permissions.Camera>();
            }
            return status;
        }

        public bool ValidateBarcodeFormat(BarcodeResult barcodeResult)
        {
            if (barcodeResult == null || string.IsNullOrWhiteSpace(barcodeResult.Value))
                return false;

            var format = barcodeResult.Format;
            return format == BarcodeFormat.Ean13 ||
                   format == BarcodeFormat.Ean8 ||
                   format == BarcodeFormat.UpcA ||
                   format == BarcodeFormat.UpcE ||
                   format == BarcodeFormat.Code128 ||
                   format == BarcodeFormat.Code39 ||
                   format == BarcodeFormat.Itf;
        }
    }
}