using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Maui.Networking;

namespace EscanerEmpresa.Services
{
    public interface INetworkService
    {
        string HealthEndpointUrl { get; set; }
        Task<bool> IsCorporateNetworkAvailableAsync(CancellationToken cancellationToken = default);
        Task<string> GetNetworkDiagnosticsAsync();
    }

    public class NetworkService : INetworkService
    {
        private readonly HttpClient _httpClient;
        public const string DefaultHealthEndpoint = "https://API_EMPRESA/health";
        public string HealthEndpointUrl { get; set; } = DefaultHealthEndpoint;

        public NetworkService(HttpClient? httpClient = null)
        {
            _httpClient = httpClient ?? new HttpClient { Timeout = TimeSpan.FromSeconds(5) };
        }

        public async Task<bool> IsCorporateNetworkAvailableAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                if (Connectivity.Current.NetworkAccess != NetworkAccess.Internet)
                    return false;

                // Solo permitir si hay interfaz WiFi o Ethernet activa (rechazar datos móviles)
                bool hasWifi = false;
                foreach (var profile in Connectivity.Current.ConnectionProfiles)
                {
                    if (profile == ConnectionProfile.WiFi || profile == ConnectionProfile.Ethernet)
                    {
                        hasWifi = true;
                        break;
                    }
                }
                if (!hasWifi) return false;

                // Comprobación del endpoint /health de infraestructura corporativa
                using var response = await _httpClient.GetAsync(HealthEndpointUrl, cancellationToken);
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        public async Task<string> GetNetworkDiagnosticsAsync()
        {
            try
            {
                var access = Connectivity.Current.NetworkAccess;
                var profiles = string.Join(", ", Connectivity.Current.ConnectionProfiles);
                bool corporateOk = await IsCorporateNetworkAvailableAsync();
                return $"Acceso: {access} | Perfiles: [{profiles}] | /health corporativo: {(corporateOk ? "OK" : "NO DISPONIBLE")}";
            }
            catch (Exception ex)
            {
                return $"Error: {ex.Message}";
            }
        }
    }
}