using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using EscanerEmpresa.Helpers;
using EscanerEmpresa.Models;
using Microsoft.Maui.Storage;

namespace EscanerEmpresa.Services
{
    public interface IFileService
    {
        string PendingDirectory { get; }
        string SentDirectory { get; }
        Task<PendingFile> CreateBarcodeFileAsync(string rawBarcode, DateTime? timestamp = null);
        Task<List<PendingFile>> GetPendingFilesAsync();
        Task MarkFileAsSentAsync(string fileName);
        Task<string> ReadFileContentAsync(string filePath);
        Task<bool> DeleteFileAsync(string filePath);
    }

    public class FileService : IFileService
    {
        private readonly string _pendingDir;
        private readonly string _sentDir;
        private static readonly object _fileLock = new();

        public string PendingDirectory => _pendingDir;
        public string SentDirectory => _sentDir;

        public FileService()
        {
            string baseDir = FileSystem.AppDataDirectory;
            _pendingDir = Path.Combine(baseDir, "PendingFiles");
            _sentDir = Path.Combine(baseDir, "SentFiles");

            lock (_fileLock)
            {
                if (!Directory.Exists(_pendingDir)) Directory.CreateDirectory(_pendingDir);
                if (!Directory.Exists(_sentDir)) Directory.CreateDirectory(_sentDir);
            }
        }

        public async Task<PendingFile> CreateBarcodeFileAsync(string rawBarcode, DateTime? timestamp = null)
        {
            if (string.IsNullOrWhiteSpace(rawBarcode))
                throw new ArgumentException("El código no puede ser nulo.", nameof(rawBarcode));

            string fileName = FileNameFormatter.GenerateUniqueFileName(rawBarcode, _pendingDir, timestamp);
            string fullPath = Path.Combine(_pendingDir, fileName);

            // UTF-8 sin BOM para máxima compatibilidad
            var utf8WithoutBom = new UTF8Encoding(false);
            byte[] bytes = utf8WithoutBom.GetBytes(rawBarcode);

            await Task.Run(() =>
            {
                lock (_fileLock) { File.WriteAllBytes(fullPath, bytes); }
            });

            var fileInfo = new FileInfo(fullPath);
            return new PendingFile(fileName, fullPath, rawBarcode, fileInfo.Length);
        }

        public async Task<List<PendingFile>> GetPendingFilesAsync()
        {
            return await Task.Run(() =>
            {
                var list = new List<PendingFile>();
                lock (_fileLock)
                {
                    if (!Directory.Exists(_pendingDir)) return list;
                    var files = Directory.GetFiles(_pendingDir, "*.txt");
                    foreach (var path in files)
                    {
                        try
                        {
                            var info = new FileInfo(path);
                            string content = File.ReadAllText(path, new UTF8Encoding(false));
                            list.Add(new PendingFile(info.Name, path, content, info.Length)
                            {
                                CreatedAt = info.CreationTimeUtc
                            });
                        }
                        catch { }
                    }
                }
                return list;
            });
        }

        public async Task MarkFileAsSentAsync(string fileName)
        {
            await Task.Run(() =>
            {
                lock (_fileLock)
                {
                    string sourcePath = Path.Combine(_pendingDir, fileName);
                    string destPath = Path.Combine(_sentDir, fileName);

                    if (File.Exists(sourcePath))
                    {
                        if (File.Exists(destPath)) File.Delete(destPath);
                        File.Move(sourcePath, destPath);
                    }
                }
            });
        }

        public async Task<string> ReadFileContentAsync(string filePath)
        {
            return await Task.Run(() =>
            {
                lock (_fileLock) { return File.ReadAllText(filePath, new UTF8Encoding(false)); }
            });
        }

        public async Task<bool> DeleteFileAsync(string filePath)
        {
            return await Task.Run(() =>
            {
                lock (_fileLock)
                {
                    if (File.Exists(filePath)) { File.Delete(filePath); return true; }
                    return false;
                }
            });
        }
    }
}