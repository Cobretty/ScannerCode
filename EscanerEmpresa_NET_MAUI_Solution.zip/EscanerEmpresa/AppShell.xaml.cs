using Microsoft.Maui.Controls;

namespace EscanerEmpresa
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}