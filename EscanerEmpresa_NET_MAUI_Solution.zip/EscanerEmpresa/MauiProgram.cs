using System.Net.Http;
using EscanerEmpresa.Services;
using EscanerEmpresa.ViewModels;
using EscanerEmpresa.Views;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Maui.Controls.Hosting;
using Microsoft.Maui.Hosting;
using ZXing.Net.Maui.Controls;

namespace EscanerEmpresa
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .UseBarcodeReader(); // Inicializa ZXing.Net.Maui para Android

            // Inyección de dependencias (Arquitectura Sección 9)
            builder.Services.AddSingleton<HttpClient>();
            builder.Services.AddSingleton<INetworkService, NetworkService>();
            builder.Services.AddSingleton<IFileService, FileService>();
            builder.Services.AddSingleton<IApiService, ApiService>();
            builder.Services.AddSingleton<IScannerService, ScannerService>();

            builder.Services.AddTransient<MainViewModel>();
            builder.Services.AddTransient<MainPage>();

            return builder.Build();
        }
    }
}