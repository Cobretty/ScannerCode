using System;

namespace EscanerEmpresa.Models
{
    /// <summary>
    /// Representa un archivo TXT pendiente de envío a la API REST corporativa.
    /// </summary>
    public class PendingFile
    {
        public string FileName { get; set; } = string.Empty;
        public string FilePath { get; set; } = string.Empty;
        public string Barcode { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public int RetryCount { get; set; } = 0;
        public string? LastError { get; set; }
        public long SizeBytes { get; set; } = 0;

        public PendingFile() { }

        public PendingFile(string fileName, string filePath, string barcode, long sizeBytes)
        {
            FileName = fileName;
            FilePath = filePath;
            Barcode = barcode;
            SizeBytes = sizeBytes;
            CreatedAt = DateTime.UtcNow;
        }
    }
}