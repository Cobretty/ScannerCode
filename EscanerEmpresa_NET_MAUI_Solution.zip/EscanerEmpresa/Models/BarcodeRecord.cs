using System;

namespace EscanerEmpresa.Models
{
    /// <summary>
    /// Modelo que representa un registro de código de barras leído.
    /// IMPORTANTE: El código se almacena estrictamente como string para preservar
    /// ceros iniciales y formatos específicos sin conversiones numéricas.
    /// </summary>
    public class BarcodeRecord
    {
        public string RawCode { get; set; } = string.Empty;
        public string Format { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public string GeneratedFileName { get; set; } = string.Empty;
        public string FullFilePath { get; set; } = string.Empty;
        public bool IsSent { get; set; } = false;

        public BarcodeRecord() { }

        public BarcodeRecord(string rawCode, string format)
        {
            RawCode = rawCode ?? string.Empty;
            Format = format ?? string.Empty;
            Timestamp = DateTime.UtcNow;
        }
    }
}