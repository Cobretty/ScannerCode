using System;
using EscanerEmpresa.ViewModels;
using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Controls;
using ZXing.Net.Maui;

namespace EscanerEmpresa.Views
{
    public partial class MainPage : ContentPage
    {
        private readonly MainViewModel _viewModel;

        public MainPage(MainViewModel viewModel)
        {
            InitializeComponent();
            BindingContext = _viewModel = viewModel;
        }

        private void OnBarcodesDetected(object? sender, BarcodeDetectionEventArgs e)
        {
            if (e.Results == null || e.Results.Length == 0) return;

            MainThread.BeginInvokeOnMainThread(async () =>
            {
                await _viewModel.HandleBarcodeDetectedAsync(e.Results);
            });
        }
    }
}